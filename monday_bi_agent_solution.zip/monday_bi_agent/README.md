
## Monday.com BI Agent

### Project Overview

This project implements a simple Business Intelligence agent that connects directly to Monday.com boards and provides quick operational insights through natural language questions.

The idea behind this system was to reduce the need for manual board checks and enable leadership-level visibility into execution and deal status.

Instead of exporting data or creating dashboards, users can ask direct questions like:

* How many work orders do we have?
* Are any work orders delayed?
* Do we have deals at risk?

The system retrieves live data from Monday.com and returns actionable responses.

---

### What the Agent Does

The agent currently supports:

* Live integration with Monday.com via API
* Querying both Deals and Work Orders boards
* Identifying delayed work orders
* Flagging deals that may be at risk
* Handling incomplete or messy data fields

All responses are generated dynamically based on real-time board data.

---

### Business Logic Used

#### Delayed Work Orders

A work order is considered delayed if:

* Its due date has passed
* It is not marked as completed

This mirrors how execution delays are typically tracked in real operations.

---

#### Deals at Risk

Deals are flagged as “at risk” when their workflow appears stalled, such as:

* Stuck
* Pending
* Ongoing negotiation

This provides early visibility into pipeline slowdowns.

---

### How It Works

The system has a modular structure:

| Component        | Role                                |
| ---------------- | ----------------------------------- |
| Monday API Layer | Fetches live board data             |
| Insight Engine   | Processes business queries          |
| Streamlit UI     | Provides a conversational interface |

---

### Running the Project

Install dependencies:

```
pip install -r requirements.txt
```

Configure environment variables in `.env`:

```
MONDAY_API_TOKEN=your_token
DEALS_BOARD_ID=your_deals_board_id
WORK_BOARD_ID=your_work_orders_board_id
```

Run the application:

```
streamlit run app.py
```

---

### Example Questions

You can try:

* How many deals do we have?
* How many work orders do we have?
* Show delayed work orders
* Show deals at risk

---

### Assumptions

Some fields across boards may be inconsistent, so the agent:

* Attempts safe parsing of dates
* Ignores missing values
* Focuses only on meaningful operational signals

---

### Future Improvements

Possible next steps include:

* NLP-based intent detection
* Predictive delay alerts
* Sector-level pipeline insights

---



