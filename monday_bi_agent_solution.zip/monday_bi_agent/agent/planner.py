def plan(query):
    return "fetch_boards"